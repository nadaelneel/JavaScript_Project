// start loading page
var loding = document.getElementById('loading');
window.addEventListener('load', function () {
    loding.style.display = 'none';
})
// end loading page


let data; let genresdata; var xhr; var count; var movies_name; var actionMovies; var comedyMovies; var dramaMovies; var advenMovies;
var animMovies; var horrorMovies; var familyMovies; var fantasyMovies;
var allMovi = document.getElementById("movieCards");
var movieGenre = document.querySelectorAll('.nav-item');
var imgPart = 'https://image.tmdb.org/t/p/w500';
var checkLocalS = JSON.parse(localStorage.getItem('favIcon'));
console.log(checkLocalS);

// start get data form api

xhr = new XMLHttpRequest();
xhr.open('Get', 'https://api.themoviedb.org/3/genre/movie/list?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
xhr.send();
xhr.onreadystatechange = function () {
    if (xhr.readyState == 4 && xhr.status == 200) {
        genresdata = JSON.parse(xhr.responseText).genres;
    }
}

var movies = new XMLHttpRequest();
movies.open('Get', 'https://api.themoviedb.org/3/trending/all/day?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
movies.send();
movies.onreadystatechange = function () {
    if (movies.readyState == 4 && movies.status == 200) {
        res();
        getGenreArr(data);
        displayMovies(data);
        if(checkLocalS) {
            for (var favMvs of checkLocalS) {
                document.getElementById(favMvs).classList.add('fav');
            }
        }
        movieGenre.forEach(ele => ele.addEventListener('click', function () { checkMoviGenre(ele, data) }));
    }
}

function res() {
    count = 0;
    movies_name = [];
    data = JSON.parse(movies.responseText).results;
    for (let key in data) {
        for (let gen_id in data[key].genre_ids) {
            for (let index in genresdata) {
                if (data[key].genre_ids[gen_id] == genresdata[index].id) {
                    movies_name[count] = genresdata[index].name;
                    count++
                }
            }
        }
        count = 0;
        data[key].movie_name = [...new Set(movies_name)];
    }
    return data;
}
function getGenreArr(_data) {
    actionMovies = data.filter(ele => ele.movie_name.includes('Action'));
    comedyMovies = data.filter(ele => ele.movie_name.includes('Comedy'));
    dramaMovies = data.filter(ele => ele.movie_name.includes('Drama'));
    advenMovies = data.filter(ele => ele.movie_name.includes('Adventure'));
    animMovies = data.filter(ele => ele.movie_name.includes('Animation'));
    horrorMovies = data.filter(ele => ele.movie_name.includes('Horror'));
    familyMovies = data.filter(ele => ele.movie_name.includes('Family'));
    fantasyMovies = data.filter(ele => ele.movie_name.includes('Fantasy'));
}
// // end get data form api
// start display data in movies page
function displayMovies(_data) {
    let count = 0;
    allMovi.innerHTML = '';
    for (var i = 0; i < _data.length; i++) {
        allMovi.innerHTML += `<div class="movie-item">
                <button class="fav-btn" id="icon${+ count}" onclick="fav(this ,${_data[i].id})"><i class="fa fa-heart"></i></button>
                <div class="img_item" onclick="getDetails(${_data[i].id})"><img src="${imgPart + _data[i].poster_path}"></div>
                    <div class="movie-title">
                        <h5 class="title"><a href="#">${_data[i].original_title}</a></h5>
                    </div>
                        <ul>
                            <li class="lang">${_data[i].original_language}</li>
                            <li class="date">${_data[i].release_date}</li>
                        </ul>
                </div>`;
        count++;
    }
    
}

function checkMoviGenre(_ele, _data) {
    // var eleId = _ele.getAttribute('id');
    if (_ele.getAttribute('id') == 'action') {
        activeGenre(_ele);
        displayMovies(actionMovies);
    }
    if (_ele.getAttribute('id') == 'comedy') {
        activeGenre(_ele);
        displayMovies(comedyMovies);
    }
    if (_ele.getAttribute('id') == 'adventure') {
        activeGenre(_ele);
        displayMovies(advenMovies);
    } 
    if (_ele.getAttribute('id') == 'horror') {
        activeGenre(_ele);
        displayMovies(horrorMovies);
    }
    if (_ele.getAttribute('id') == 'animation') {
        activeGenre(_ele);
        displayMovies(animMovies);
    }
    if (_ele.getAttribute('id') == 'drama') {
        activeGenre(_ele);
        displayMovies(dramaMovies);
    }
    if (_ele.getAttribute('id') == 'family') {
        activeGenre(_ele);
        displayMovies(familyMovies);
    }
    if (_ele.getAttribute('id') == 'fantasy') {
        activeGenre(_ele);
        displayMovies(fantasyMovies);
    }
    if (_ele.getAttribute('id') == 'allItems') {
        activeGenre(_ele);
        displayMovies(_data);
    }
}

function activeGenre(_active) {
    movieGenre.forEach(li => {
        li.classList.remove('active');
    })
    _active.classList.add('active')
}
function getDetails(_id) {
    localStorage.setItem('moviId', _id);
    window.location.href = "./movi-details.html";
}
// end display data in movies page
// start set fav movies to local storage
var favIcon = [];
let favArr = [];
function fav(_this , _moviId) {
    _this.classList.toggle('fav');
    if (_this.classList.contains('fav')) {
        favIcon.push(_this.id);
        localStorage.setItem('favIcon', JSON.stringify(favIcon))
        favArr.push(_moviId);
        localStorage.setItem('fav', JSON.stringify(favArr));
    } else {
        favArr.splice(favArr.indexOf(_moviId), 1);
        localStorage.setItem('fav', JSON.stringify(favArr));
    }
    
}
// end set fav movies to local storage
// start search part
var searchBtn_div = document.getElementById("search");
var searchBtn_form = document.getElementById("searchBtn");
var closeIcon = document.getElementById('closeIcon');
var searchInput = document.getElementById("searchInput");
searchBtn_form.addEventListener('click', function (e) {
    e.preventDefault();
    searchBtn_div.style.top = '0';
})
closeIcon.addEventListener('click', function (e) {
    e.preventDefault();
    searchBtn_div.style.top = "-100%";
})
searchInput.addEventListener('keyup', function (e) {
    if (e.key == 'Enter') {
        allMovi.innerHTML = '';
        for (const key in data) {
            if (data[key].title != undefined) {
                var bool = data[key].title.includes(searchInput.value);
                console.log("data[key].title.includes(searchInput.value);", data[key].title.includes(searchInput.value))
                if (bool == true) {
                    let count = 0;

                    // for (var i = 0; i < data.length; i++) {
                    allMovi.innerHTML += `<div class="movie-item">
                            <button class="fav-btn" id="icon${+ count}" onclick="fav(this , ${data[key].id})"><i class="fa fa-heart"></i></button>
                            <div class="img_item" onclick="getDetails(${data[key].id})"><img src="${imgPart + data[key].poster_path}"></div>
                                <div class="movie-title">
                                    <h5 class="title"><a href="#">${data[key].title}</a></h5>
                                </div>
                                    <ul>
                                        <li class="lang">${data[key].original_language}</li>
                                        <li class="date">${data[key].release_date}</li>
                                    </ul>
                            </div>`;
                    // }
                    count++;
                }
            }
        }
    }
})

// end search part
