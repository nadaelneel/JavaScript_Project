// start get data form api
let data; let genresdata; var count; var movies_name; let moviId; let details; var res;
var moviDetails = document.getElementById('moviDetails');
var simiCards = document.getElementById('simiCards')
var imgPart = 'https://image.tmdb.org/t/p/w500';
var xhr = new XMLHttpRequest();
xhr.open('Get', 'https://api.themoviedb.org/3/genre/movie/list?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
xhr.send();
xhr.onreadystatechange = function () {
    if (xhr.readyState == 4 && xhr.status == 200) {
        genresdata = JSON.parse(xhr.responseText).genres;
    }
}

var movies = new XMLHttpRequest();
movies.open('Get', 'https://api.themoviedb.org/3/trending/all/day?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
movies.send();
movies.onreadystatechange = function () {
    if (movies.readyState == 4 && movies.status == 200) {
        getRes();
        getDetails(data);
    }
}
function getRes() {
    count = 0;
    movies_name = [];
    data = JSON.parse(movies.responseText).results;
    for (let key in data) {
        for (let gen_id in data[key].genre_ids) {
            for (let index in genresdata) {
                if (data[key].genre_ids[gen_id] == genresdata[index].id) {
                    movies_name[count] = genresdata[index].name;
                    count++
                }
            }
        }
        count = 0;
        data[key].movie_name = [...new Set(movies_name)];
    }
    return data;
}



// start details page
function getDetails(_data) {
    moviId =localStorage.getItem('moviId');
    details = _data.filter(ele => ele.id == moviId);
    display(details);
}


function display(_movie) {
    var count = 0;
    moviDetails.innerHTML = `<div class="movi-img movi-poster">
            <img src="${imgPart + _movie[0].poster_path}" alt="">
        </div>
        <div class="movi-desc">
            <div>
                <h2>${_movie[0].title}</h2>
                <button class="fav-btn" id="icon${+ count}" onclick="fav(this ,${_movie[0].id})"><i class="fa fa-heart"></i></button>
            </div>
            <div class="rate"><i class="fa-solid fa-thumbs-up"></i>${_movie[0].vote_average}</div>
            <p class="overview">
                ${_movie[0].overview}
            </p>
            <span class='movie-genre'>${_movie[0].movie_name}</span>
            <div>
                <span><b>${_movie[0].original_language}<b></span>
                <span>${_movie[0].release_date}</span>
            </div>

            <div class="watch-btn">
                <button class="watchNow-btn">Watch Now</button>
                <button class="watchNow-btn">Watch Trailer</button>
            </div>
        </div>`;
    count++
}
// end details page

// start smilar movies section
moviId = localStorage.getItem('moviId');
var simlr = new XMLHttpRequest();
simlr.open('Get', `https://api.themoviedb.org/3/movie/${moviId}/similar?api_key=c3caf934adc9ebe65b5d2adce9ce234d`)
simlr.send();
simlr.onreadystatechange = function () {
    if (simlr.readyState == 4 && simlr.status == 200) {
        res = JSON.parse(simlr.responseText).results;
        for (var i = 0; i < 4;i++) {
            simiCards.innerHTML += `<div class="card">
            <div class="card-img">
                <img src="${imgPart + res[i].poster_path}" alt="">
            </div>
        </div>`
        }
    }
}
// end similar movies section
// start set fav movie
let favArr = [];
function fav(_this, _moviId) {
    _this.classList.toggle('fav');
    if (_this.classList.contains('fav')) {
        favArr.push(_moviId);
        localStorage.setItem('fav', JSON.stringify(favArr));
    } else {
        favArr.splice(favArr.indexOf(_moviId), 1);
        localStorage.setItem('fav', JSON.stringify(favArr));
    }
}
// end set fav movie