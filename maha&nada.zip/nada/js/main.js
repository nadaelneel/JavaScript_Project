// start loading page
var loding = document.getElementById('loading');
window.addEventListener('load', function () {
    loding.style.display = 'none';
})
// end loading page





// start get data form api
let data; let genresdata; var count; var movies_name; var actionMovies; var comedyMovies; var dramaMovies; var advenMovies;
var animMovies; var horrorMovies; var familyMovies; var fantasyMovies;
var list = document.querySelectorAll('.categories li');
var topMovi = document.getElementById("moviHomeCards");
var allMovi = document.getElementById("movieCards");
var movieGenre = document.querySelectorAll('.movie-content .nav-item');
// console.log(movieGenre);
// check isUser??
var user_obj = JSON.parse(localStorage.getItem("user"));
if (user_obj) {
    document.getElementById('signin_btn').innerHTML = " "
    document.getElementById('signin_btn').innerHTML = `<button id="signIcon" class="signin-icon" onclick="getFavPage()">
    <i class="fa-regular fa-user"></i></a></button> <p class="name_of_user" style="color:white; margin-top:5px;">${user_obj.name}</p>`;
}
else {
    var user_name = localStorage.getItem("user");
    document.getElementById('signin_btn').innerHTML = " "
    document.getElementById('signin_btn').innerHTML = `<button id="signIcon" class="signin-btn">
    <i class="fa-regular fa-user"></i>
    SIGN UP </button>`
}
// end check

var imgPart = 'https://image.tmdb.org/t/p/w500';
var xhr = new XMLHttpRequest();
xhr.open('Get', 'https://api.themoviedb.org/3/genre/movie/list?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
xhr.send();
xhr.onreadystatechange = function () {
    if (xhr.readyState == 4 && xhr.status == 200) {
        genresdata = JSON.parse(xhr.responseText).genres;
    }
}




var movies = new XMLHttpRequest();
movies.open('Get', 'https://api.themoviedb.org/3/trending/all/day?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
movies.send();
movies.onreadystatechange = function () {
    if (movies.readyState == 4 && xhr.status == 200) {
        getRes();
        actionMovies = data.filter(ele => ele.movie_name.includes('Action'));
        comedyMovies = data.filter(ele => ele.movie_name.includes('Comedy'));
        dramaMovies = data.filter(ele => ele.movie_name.includes('Drama'));
        advenMovies = data.filter(ele => ele.movie_name.includes('Adventure'));
        displayTrending(data)
        list.forEach(ele => ele.addEventListener('click', function () { checkGenre(ele, data) }));
    }
}
function getRes() {
    count = 0;
    movies_name = [];
    data = JSON.parse(movies.responseText).results;
    for (let key in data) {
        for (let gen_id in data[key].genre_ids) {
            for (let index in genresdata) {
                if (data[key].genre_ids[gen_id] == genresdata[index].id) {
                    movies_name[count] = genresdata[index].name;
                    count++
                }
            }
        }
        count = 0;
        data[key].movie_name = [...new Set(movies_name)];
    }
    return data;
}
// // end get data form api





// // start get trending movies at home page
function displayTrending(_genre) {
    topMovi.innerHTML = '';
    for (var i = 0; i < 7; i++) {
        topMovi.innerHTML += `<div class="movi-card">
            <div class="movi-img" onclick="getDetails(${_genre[i].id})">
            <img src="${imgPart + _genre[i].poster_path}" alt="">
            </div>
            <div class="movi-title">
                <h3>${_genre[i].original_title}</h3>
                <span class="rate"><i class="fa-solid fa-thumbs-up"></i>${_genre[i].vote_average}</span>
            </div>
            </div>`;
    }
    console.log(_genre);
}
function checkGenre(_ele, _data) {
    if (_ele.getAttribute('id') == 'action') {
        activeGenre(_ele);
        displayTrending(actionMovies);

    }
    if (_ele.getAttribute('id') == 'comedy') {
        activeGenre(_ele);
        displayTrending(comedyMovies);

    }
    if (_ele.getAttribute('id') == 'drama') {
        activeGenre(_ele);
        displayTrending(dramaMovies);

    }
    if (_ele.getAttribute('id') == 'adv') {
        activeGenre(_ele);
        displayTrending(advenMovies);
    }
    if (_ele.getAttribute('id') == 'all') {
        activeGenre(_ele);
        displayTrending(_data);
    }
}
function activeGenre(e) {
    list.forEach(li => {
        li.classList.remove('active-cate');
    })
    e.classList.add('active-cate')
}
// end get trending movies at home page

// // // start signForm section
var signForm = document.getElementById('signForm');
var signIcon = document.getElementById('signIcon');
var closeIcon = document.getElementById('closeIcon');
var regForm = document.getElementById('regForm');
var logForm = document.getElementById('logForm');
var register = document.getElementById('register');
var logIn = document.getElementById('logIn');
signIcon.addEventListener('click', function () {
    signForm.style.bottom = 0;
    signForm.style.position = 'fixed';
});
closeIcon.addEventListener('click', function () {
    signForm.style.bottom = 100 + '%';
})
regForm.addEventListener('click', function () {
    register.style.display = 'flex';
    logIn.style.display = 'none';
    logForm.style.color = '#dddddd';
    regForm.style.color = 'black';
})
logForm.addEventListener('click', function () {
    logInForm();
})
// // end signForm section
// start reg-validation
var regInput = document.querySelectorAll('.regs-form input');
var userName = document.getElementById('userName');
var email = document.getElementById('email');
var pass = document.getElementById('pass');
var regSignUp = document.getElementById('regSignUp');
var err = document.getElementById('err');
var passErr = document.getElementById('passErr');
var namePtrn = /^[a-zA-Z]+$/;
var emailPtrn = /^[\w\-\.]+@([\w-]+\.)+[\w-]{2,4}$/;

regSignUp.addEventListener('click', function (e) {
    e.preventDefault();
    if (!namePtrn.test(userName.value)) {
        userName.style.border = '1px solid red';
        err.style.display = 'block';
        err.innerHTML = 'Name must be made up of alphabets only';
    } else if (!emailPtrn.test(email.value)) {
        userName.style.border = '1px solid rgba(0, 0, 0, 0.12)';
        err.style.display = 'none';
        email.style.border = '1px solid red';
    } else if (pass.value.length < 8) {
        email.style.border = '1px solid rgba(0, 0, 0, 0.12)';
        pass.style.border = '1px solid red';
        passErr.style.display = 'block';
        passErr.innerHTML = 'password is very short';
    } else {
        pass.style.border = '1px solid rgba(0, 0, 0, 0.12)';
        err.style.display = 'none';
        localStorage.setItem('user', JSON.stringify({ name: userName.value, email: email.value, pass: pass.value }));
        logInForm();
    }

})

function logInForm() {
    logIn.style.display = 'flex';
    register.style.display = 'none';
    regForm.style.color = '#dddddd';
    logForm.style.color = 'black';
}
// end reg-validation
// start logn-validation
var logEmail = document.getElementById('lognEmail');
var logPass = document.getElementById('lognPass');
var lognBtn = document.getElementById('signIn');
var lgnSucc = document.getElementById('succSign');
var getUser = JSON.parse(localStorage.getItem('user'));
lognBtn.addEventListener('click', function () {
    

    if (logEmail.value != getUser.email) {
        logEmail.style.border = '1px solid red';
        return;
    } else { logEmail.style.border = '1px solid rgba(0, 0, 0, 0.12)' };
    if (logPass.value != getUser.pass) {
        logPass.style.border = '1px solid red';
    } else {
        logPass.style.border = '1px solid rgba(0, 0, 0, 0.12)';
        window.location.href = "./index.html";
    }
})

// // end logn-validation
// start bind fav page
function getFavPage() {
    document.getElementById('signForm').style.display = 'none';
    window.location.href = "./fav.html";
}
// end bind fav page
function getDetails(_id) {
    localStorage.setItem('moviId', _id);
    window.location.href = "./movi-details.html";
}