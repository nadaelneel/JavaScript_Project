var fav_body = document.getElementById("cards_fav_body");



var movie_list = new XMLHttpRequest();
movie_list.open('Get', 'https://api.themoviedb.org/3/genre/movie/list?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
movie_list.send();

let data;
let arr2;
movie_list.onreadystatechange = function () {
    if (movie_list.readyState == 4 && movie_list.status == 200) {
        arr2 = JSON.parse(movie_list.responseText).genres;
    }
}
///////////////////////////////////////////////////
var imgPart = 'https://image.tmdb.org/t/p/w500';
var movies = new XMLHttpRequest();
movies.open('Get', 'https://api.themoviedb.org/3/trending/all/day?api_key=c3caf934adc9ebe65b5d2adce9ce234d')
movies.send();


let arr;
var fav_id = [];
movies.onreadystatechange = function () {
    if (movies.readyState == 4 && movies.status == 200) {
        var xx = 0;
        var movies_name = [];
        data = JSON.parse(movies.responseText).results;
        for (let key in data) {
            for (let gen_id in data[key].genre_ids) {
                for (let index in arr2) {
                    if (data[key].genre_ids[gen_id] == arr2[index].id) {
                        movies_name[xx] = arr2[index].name;
                        xx++;
                    }
                }
            }
            xx = 0;
            data[key].movie_name = [...new Set(movies_name)];
        }

        display(data);
    }

}

var getFav = JSON.parse(localStorage.getItem('fav'));
// if (getFav) {
//     document.getElementById("emptyPage").style.display = "none";
// } else {
//     document.getElementById("emptyPage").style.display = "block";
// }
function display(data) {
    console.log(data);
    fav_body.innerHTML = "";
    for (var _id of getFav) {
        var favMovies = data.filter(ele => ele.id == _id);
        favMovies.forEach(ele => {
            fav_body.innerHTML += `<div class="card_fav" id="card_id">
            <div id="watch" class="play">
            <img src="${imgPart + ele.poster_path}">
        </div>
        <div id="content">
        <button class= "heart-icon" onclick="remov_fav(${ele.id})"><i class="fa fa-heart"></i></button><br>
            <span class="mov_name"><i class="fa fa-bookmark"></i>${ele.movie_name[0]}</span><br>
            <span class="mov_name"><i class="fa fa-clock-o"></i>150 Min</span>
            <h3 class="fav_title">${ele.title}</h3>
        </div>
    </div>`
        });
    }
}
// remove movie from fav
function remov_fav(id) {
    var x = getFav.indexOf(id);
    getFav.splice(x, 1);
    console.log(getFav);
    localStorage.setItem('fav', JSON.stringify(getFav));
    display();
}
// end movie from fav


